from distutils.core import setup

setup(
    name='Controller',
    version="0.1ctr",
    packages=['ctrl', ],
    license="MIT",
    long_description=open('README.txt').read(),
)
