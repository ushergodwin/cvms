"""
If you use pymysql or mysqlclient or MySQLdb drivers, then the
ENGINE: 'django.db.backends.mysql'
put this code bellow before any python code, recommended in manage.py
try:
    import pymysql
    pymysql.install_as_MySQLdb()
except:
    pass

If you use mysql connector/python, then the
ENGINE: mysql.connector.django
"""
Config = {
    "HOST": 'localhost',
    "USER": 'root',
    "PASSWORD": 'groupc',
    "DATABASE": 'gema',
    "DB_DRIVER": {
        "mysqldb": None,
        "mysqlclient": None,
        "pymysql": True,
        "mysql_connector": None
    }
}
